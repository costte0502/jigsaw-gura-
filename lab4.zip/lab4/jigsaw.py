import turtle
import random
#置入圖片
#打亂圖片
#允許移動圖片
#檢查圖片的坐標
#返回正確或者錯誤
win = turtle.Screen()
win.screensize(canvwidth=500, canvheight=500,bg="cyan")
randp = 300
randn = -300
allTurtles = []
row = 0# as a index for image adding in for loop
def createturtles(r):
    turtle.up()
    turtle.hideturtle()
    addturshape(r)
    for k in range(16):
        if k ==0:
            r==0
        elif k%4==0:
            r+=1
        newTur= turtle.Turtle()
        #define turtle attributes
        newTur.speed(0)
        newTur.up()
        newTur.goto(random.randint(randn,randp),random.randint(randn,randp))
        newTur.shape("image-"+str(r)+"-"+str(k%4)+".gif")
        newTur.ondrag(newTur.goto)
        #then,collect them into list
        allTurtles.append(newTur)
     
#add all pics to system
def addturshape(r):
    for k in range(16):
        if k ==0:
            r==0
        elif k%4==0:
            r+=1
        turtle.addshape("image-"+str(r)+"-"+str(k%4)+".gif")
#check the position of turtles
#1.拼好了
#2.按c檢查
    #檢查每塊拼圖的位置
        #例如1在左邊，2在右，我們有1x2的window，按順序來說，2相對於1就是如果2的坐標大於1，就錯
#3.如對，則返回對；錯則返回錯
def checkJigsaw():
    countforbool= 0
    base = 4
    checking = False
    for i in range(4):
        for j in range(3):
            if allTurtles[j+i*base].xcor()<allTurtles[(j+1)+i*base].xcor() and allTurtles[j*base+i].ycor()>allTurtles[i+(j+1)*base].ycor():
                countforbool +=1
            else:
                continue


    if countforbool == 12:
        checking = True

    turtle.clear()
    turtle.hideturtle()
    turtle.up()
    turtle.goto(0,-300)
    if checking ==True:
        
        turtle.write("Right!This is Gawr Gura",font=("Arial",20,"normal"))
        
    else:
        turtle.write("Wrong!Try again",font=("Arial",20,"normal"))
        
createturtles(row)

turtle.onkeypress(checkJigsaw,"c")

turtle.listen()
turtle.done()
